package weather.wu.com.more.bean;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by 吴海辉 on 2017/2/20.
 */
public class Joke {

    /**
     * showapi_res_code : 0
     * showapi_res_error :
     * showapi_res_body : {"totalNum":20,"ret_code":0,"list":[{"thumburl":"http://ww3.sinaimg.cn/large/bd698b0fjw1ep7xvm84fuj20c80im3zn.jpg","title":"妹子COS的好走心啊！","height":"670","sourceurl":"http://down.laifudao.com/images/tupian/20152102311.jpg","width":"440","class":"1","url":"http://www.laifudao.com/tupian/41418.htm"},{"thumburl":"http://ww2.sinaimg.cn/large/bc9f5ba3jw1dzbs8hoh6nj.jpg","title":"慢点儿！你他妈要摔死我啊！","height":"468","sourceurl":"http://down.laifudao.com/images/tupian/d11202134.jpg","width":"342","class":"5","url":"http://www.laifudao.com/tupian/11203.htm"},{"thumburl":"http://ww2.sinaimg.cn/large/e4e2bea6jw1ep92gs8dyzj20hs0kjmya.jpg","title":"运气不好，谁能笑得出来！","height":"739","sourceurl":"http://down.laifudao.com/images/tupian/2015211112658.jpg","width":"640","class":"1","url":"http://www.laifudao.com/tupian/41447.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd698b0fjw1epcdun7i9mj20c80dzdgz.jpg","title":"为什么我一拉开钱包，商场的人都躲桌子底下了","height":"503","sourceurl":"http://down.laifudao.com/images/tupian/201521420470.jpg","width":"440","class":"1","url":"http://www.laifudao.com/tupian/41533.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/e4e2bea6jw1edmcfphyczj20go0ljq3t.jpg","title":"这是哪里的硬币？好厉害的样子！","height":"775","sourceurl":"http://down.laifudao.com/images/tupian/201421521442.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/29878.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd759d6djw1e1p9k6bwyfj.jpg","title":"没有什么可以阻挡我们的热情","height":"493","sourceurl":"http://down.laifudao.com/images/tupian/201329193838.jpg","width":"500","class":"5","url":"http://www.laifudao.com/tupian/21011.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd698b0fjw1f1dzcd8owtj20dr0cvgma.jpg","title":"这东西你们屌丝能吃的起吗","height":"463","sourceurl":"http://down.laifudao.com/images/tupian/201622172526.jpg","width":"495","class":"1","url":"http://www.laifudao.com/tupian/54296.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/e4e2bea6jw1ep0qpbyrikj20av0d4t94.jpg","title":"婚前必须练过，不然\u2026\u2026","height":"472","sourceurl":"http://down.laifudao.com/images/tupian/201524205916.jpg","width":"391","class":"1","url":"http://www.laifudao.com/tupian/41297.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd698b0fjw1eox6suka3uj20c80ez0tk.jpg","title":"一口饮料，两种体验","height":"539","sourceurl":"http://down.laifudao.com/images/tupian/201513020128.jpg","width":"440","class":"1","url":"http://www.laifudao.com/tupian/41177.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/e4e2bea6jw1f17t42dibcj20gg0cbdhb.jpg","title":"准备登陆了","height":"443","sourceurl":"http://down.laifudao.com/images/tupian/20161309482.jpg","width":"592","class":"5","url":"http://www.laifudao.com/tupian/54179.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd759d6djw1e1yikfbkhaj.jpg","title":"如此巨乳","height":"835","sourceurl":"http://down.laifudao.com/images/tupian/2013218185416.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/21206.htm"},{"thumburl":"http://ww2.sinaimg.cn/large/e4e2bea6jw1edt63wc9mzj20go0kmwfs.jpg","title":"毫无违和感！","height":"742","sourceurl":"http://down.laifudao.com/images/tupian/2014222221653.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/30058.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd759d6djw1f0sz990b1wj20da0fcjs5.jpg","title":"戴帽子的那个肯定是心机婊","height":"552","sourceurl":"http://down.laifudao.com/images/tupian/201611812959.jpg","width":"478","class":"1","url":"http://www.laifudao.com/tupian/53748.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd6bfb01jw1e26mnmrt0dj.jpg","title":"话说这是世界的尽头","height":"334","sourceurl":"http://down.laifudao.com/images/tupian/201322691317.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/21437.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd698b0fjw1fcl5muypb1j20dc0godgv.jpg","title":"我可能换到假硬币了！","height":"600","sourceurl":"http://down.laifudao.com/images/tupian/20172621501.jpg","width":"480","class":"1","url":"http://www.laifudao.com/tupian/66589.htm"},{"thumburl":"http://ww4.sinaimg.cn/large/bc946a85jw1dzdkoj7gftj.jpg","title":"声势浩大的港口","height":"411","sourceurl":"http://down.laifudao.com/images/tupian/28200821919155340839.jpg","width":"700","class":"7","url":"http://www.laifudao.com/tupian/8345.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bca3622fjw1dz9h926k59j.jpg","title":"书香门第就是不一样","height":"699","sourceurl":"http://down.laifudao.com/images/tupian/201221191223.jpg","width":"468","class":"1","url":"http://www.laifudao.com/tupian/15413.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd759d6djw1e21znravfwj.jpg","title":"请你吃顿猕猴桃霸王餐","height":"786","sourceurl":"http://down.laifudao.com/images/tupian/2013222101254.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/21331.htm"},{"thumburl":"http://ww4.sinaimg.cn/large/e4e2bea6jw1f0sz71gcsxj20f90ejjsf.jpg","title":"妹子，你失恋了？我来陪你说说话吧","height":"523","sourceurl":"http://down.laifudao.com/images/tupian/2016118133932.jpg","width":"549","class":"1","url":"http://www.laifudao.com/tupian/53763.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/e4e2bea6jw1f13kh4mh9hj20f60dudgt.jpg","title":"扭一扭有点困难，直接泡一泡就算了","height":"498","sourceurl":"http://down.laifudao.com/images/tupian/2016127114730.jpg","width":"546","class":"1","url":"http://www.laifudao.com/tupian/54064.htm"}]}
     */

    private int showapi_res_code;
    private String showapi_res_error;
    private ShowapiResBodyBean showapi_res_body;

    public int getShowapi_res_code() {
        return showapi_res_code;
    }

    public void setShowapi_res_code(int showapi_res_code) {
        this.showapi_res_code = showapi_res_code;
    }

    public String getShowapi_res_error() {
        return showapi_res_error;
    }

    public void setShowapi_res_error(String showapi_res_error) {
        this.showapi_res_error = showapi_res_error;
    }

    public ShowapiResBodyBean getShowapi_res_body() {
        return showapi_res_body;
    }

    public void setShowapi_res_body(ShowapiResBodyBean showapi_res_body) {
        this.showapi_res_body = showapi_res_body;
    }

    public static class ShowapiResBodyBean {
        /**
         * totalNum : 20
         * ret_code : 0
         * list : [{"thumburl":"http://ww3.sinaimg.cn/large/bd698b0fjw1ep7xvm84fuj20c80im3zn.jpg","title":"妹子COS的好走心啊！","height":"670","sourceurl":"http://down.laifudao.com/images/tupian/20152102311.jpg","width":"440","class":"1","url":"http://www.laifudao.com/tupian/41418.htm"},{"thumburl":"http://ww2.sinaimg.cn/large/bc9f5ba3jw1dzbs8hoh6nj.jpg","title":"慢点儿！你他妈要摔死我啊！","height":"468","sourceurl":"http://down.laifudao.com/images/tupian/d11202134.jpg","width":"342","class":"5","url":"http://www.laifudao.com/tupian/11203.htm"},{"thumburl":"http://ww2.sinaimg.cn/large/e4e2bea6jw1ep92gs8dyzj20hs0kjmya.jpg","title":"运气不好，谁能笑得出来！","height":"739","sourceurl":"http://down.laifudao.com/images/tupian/2015211112658.jpg","width":"640","class":"1","url":"http://www.laifudao.com/tupian/41447.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd698b0fjw1epcdun7i9mj20c80dzdgz.jpg","title":"为什么我一拉开钱包，商场的人都躲桌子底下了","height":"503","sourceurl":"http://down.laifudao.com/images/tupian/201521420470.jpg","width":"440","class":"1","url":"http://www.laifudao.com/tupian/41533.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/e4e2bea6jw1edmcfphyczj20go0ljq3t.jpg","title":"这是哪里的硬币？好厉害的样子！","height":"775","sourceurl":"http://down.laifudao.com/images/tupian/201421521442.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/29878.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd759d6djw1e1p9k6bwyfj.jpg","title":"没有什么可以阻挡我们的热情","height":"493","sourceurl":"http://down.laifudao.com/images/tupian/201329193838.jpg","width":"500","class":"5","url":"http://www.laifudao.com/tupian/21011.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd698b0fjw1f1dzcd8owtj20dr0cvgma.jpg","title":"这东西你们屌丝能吃的起吗","height":"463","sourceurl":"http://down.laifudao.com/images/tupian/201622172526.jpg","width":"495","class":"1","url":"http://www.laifudao.com/tupian/54296.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/e4e2bea6jw1ep0qpbyrikj20av0d4t94.jpg","title":"婚前必须练过，不然\u2026\u2026","height":"472","sourceurl":"http://down.laifudao.com/images/tupian/201524205916.jpg","width":"391","class":"1","url":"http://www.laifudao.com/tupian/41297.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd698b0fjw1eox6suka3uj20c80ez0tk.jpg","title":"一口饮料，两种体验","height":"539","sourceurl":"http://down.laifudao.com/images/tupian/201513020128.jpg","width":"440","class":"1","url":"http://www.laifudao.com/tupian/41177.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/e4e2bea6jw1f17t42dibcj20gg0cbdhb.jpg","title":"准备登陆了","height":"443","sourceurl":"http://down.laifudao.com/images/tupian/20161309482.jpg","width":"592","class":"5","url":"http://www.laifudao.com/tupian/54179.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd759d6djw1e1yikfbkhaj.jpg","title":"如此巨乳","height":"835","sourceurl":"http://down.laifudao.com/images/tupian/2013218185416.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/21206.htm"},{"thumburl":"http://ww2.sinaimg.cn/large/e4e2bea6jw1edt63wc9mzj20go0kmwfs.jpg","title":"毫无违和感！","height":"742","sourceurl":"http://down.laifudao.com/images/tupian/2014222221653.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/30058.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd759d6djw1f0sz990b1wj20da0fcjs5.jpg","title":"戴帽子的那个肯定是心机婊","height":"552","sourceurl":"http://down.laifudao.com/images/tupian/201611812959.jpg","width":"478","class":"1","url":"http://www.laifudao.com/tupian/53748.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bd6bfb01jw1e26mnmrt0dj.jpg","title":"话说这是世界的尽头","height":"334","sourceurl":"http://down.laifudao.com/images/tupian/201322691317.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/21437.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd698b0fjw1fcl5muypb1j20dc0godgv.jpg","title":"我可能换到假硬币了！","height":"600","sourceurl":"http://down.laifudao.com/images/tupian/20172621501.jpg","width":"480","class":"1","url":"http://www.laifudao.com/tupian/66589.htm"},{"thumburl":"http://ww4.sinaimg.cn/large/bc946a85jw1dzdkoj7gftj.jpg","title":"声势浩大的港口","height":"411","sourceurl":"http://down.laifudao.com/images/tupian/28200821919155340839.jpg","width":"700","class":"7","url":"http://www.laifudao.com/tupian/8345.htm"},{"thumburl":"http://ww3.sinaimg.cn/large/bca3622fjw1dz9h926k59j.jpg","title":"书香门第就是不一样","height":"699","sourceurl":"http://down.laifudao.com/images/tupian/201221191223.jpg","width":"468","class":"1","url":"http://www.laifudao.com/tupian/15413.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/bd759d6djw1e21znravfwj.jpg","title":"请你吃顿猕猴桃霸王餐","height":"786","sourceurl":"http://down.laifudao.com/images/tupian/2013222101254.jpg","width":"600","class":"1","url":"http://www.laifudao.com/tupian/21331.htm"},{"thumburl":"http://ww4.sinaimg.cn/large/e4e2bea6jw1f0sz71gcsxj20f90ejjsf.jpg","title":"妹子，你失恋了？我来陪你说说话吧","height":"523","sourceurl":"http://down.laifudao.com/images/tupian/2016118133932.jpg","width":"549","class":"1","url":"http://www.laifudao.com/tupian/53763.htm"},{"thumburl":"http://ww1.sinaimg.cn/large/e4e2bea6jw1f13kh4mh9hj20f60dudgt.jpg","title":"扭一扭有点困难，直接泡一泡就算了","height":"498","sourceurl":"http://down.laifudao.com/images/tupian/2016127114730.jpg","width":"546","class":"1","url":"http://www.laifudao.com/tupian/54064.htm"}]
         */

        private int totalNum;
        private int ret_code;
        private List<ListBean> list;

        public int getTotalNum() {
            return totalNum;
        }

        public void setTotalNum(int totalNum) {
            this.totalNum = totalNum;
        }

        public int getRet_code() {
            return ret_code;
        }

        public void setRet_code(int ret_code) {
            this.ret_code = ret_code;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            /**
             * thumburl : http://ww3.sinaimg.cn/large/bd698b0fjw1ep7xvm84fuj20c80im3zn.jpg
             * title : 妹子COS的好走心啊！
             * height : 670
             * sourceurl : http://down.laifudao.com/images/tupian/20152102311.jpg
             * width : 440
             * class : 1
             * url : http://www.laifudao.com/tupian/41418.htm
             */

            private String thumburl;
            private String title;
            private String height;
            private String sourceurl;
            private String width;
            @SerializedName("class")
            private String classX;
            private String url;

            public String getThumburl() {
                return thumburl;
            }

            public void setThumburl(String thumburl) {
                this.thumburl = thumburl;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getHeight() {
                return height;
            }

            public void setHeight(String height) {
                this.height = height;
            }

            public String getSourceurl() {
                return sourceurl;
            }

            public void setSourceurl(String sourceurl) {
                this.sourceurl = sourceurl;
            }

            public String getWidth() {
                return width;
            }

            public void setWidth(String width) {
                this.width = width;
            }

            public String getClassX() {
                return classX;
            }

            public void setClassX(String classX) {
                this.classX = classX;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }
        }
    }
}

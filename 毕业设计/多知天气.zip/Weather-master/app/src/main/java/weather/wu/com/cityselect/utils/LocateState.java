package weather.wu.com.cityselect.utils;

/**
 * Created by 吴海辉 on 2017/1/16.
 */
public class LocateState {
    public static final int LOCATING    = 111;
    public static final int FAILED      = 666;
    public static final int SUCCESS     = 888;
}
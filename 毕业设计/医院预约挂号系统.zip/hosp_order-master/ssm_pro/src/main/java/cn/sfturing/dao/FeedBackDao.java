package cn.sfturing.dao;

import cn.sfturing.entity.FeedBack;

public interface FeedBackDao {
	
	//插入反馈
	public int inserFeedBack(FeedBack feedBack);

}

/**
 * Created by https://github.com/kuangcp
 * CRUD的操作服务,因为Rest依赖产生的JSON不符合LayUI的格式
 * GET  查询信息 listAll getId
 * POST 修改信息
 * @author kuangcp
 * @date 18-4-28  下午8:42
 */
package top.kuangcp.graduate.service.crud;
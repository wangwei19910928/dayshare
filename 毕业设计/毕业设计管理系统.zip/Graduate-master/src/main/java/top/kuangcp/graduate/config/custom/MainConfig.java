//package top.kuangcp.graduate.config.custom;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.stereotype.Component;
//
///**
// * Created by https://github.com/kuangcp
// *
// * @author kuangcp
// * @date 18-4-22  下午7:52
// */
//@Component
//@ConfigurationProperties(prefix = "graduate.main")
//public class MainConfig {
//    private String delimiter;
//
//    public String getDelimiter() {
//        return delimiter;
//    }
//
//    public void setDelimiter(String delimiter) {
//        this.delimiter = delimiter;
//    }
//}

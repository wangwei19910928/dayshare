package top.kuangcp.graduate.wechat.handler;

/**
 * @author Binary Wang(https://github.com/binarywang)
 */
public abstract class ScanHandler extends AbstractHandler {

}

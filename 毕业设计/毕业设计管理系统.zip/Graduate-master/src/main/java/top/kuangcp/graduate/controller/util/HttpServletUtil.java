//package top.kuangcp.graduate.controller.util;
//
//import javax.servlet.http.HttpServletResponse;
//
///**
// * Created by https://github.com/kuangcp
// *
// * @author kuangcp
// * @date 18-4-30  下午12:09
// */
//public class HttpServletUtil {
//
//    public static void configResponse(HttpServletResponse response){
//        response.setContentType("application/json;charset=UTF-8");
//    }
//}

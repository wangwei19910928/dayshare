package top.kuangcp.graduate.domain.bo;

import lombok.Data;

/**
 * Created by https://github.com/kuangcp
 *
 * @author kuangcp
 * @date 18-5-9  上午8:03
 */
@Data
public class ValidateTopic {
    private String comment;
    private Integer status;
}

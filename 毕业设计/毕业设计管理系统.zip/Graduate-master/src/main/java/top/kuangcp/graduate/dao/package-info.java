/**
 * Created by https://github.com/kuangcp
 * DAO  数据持久层操作对象
 * TODO 思考能不能在Jpa上自己封装
 * @author kuangcp
 * @date 18-4-26  上午8:45
 */
package top.kuangcp.graduate.dao;
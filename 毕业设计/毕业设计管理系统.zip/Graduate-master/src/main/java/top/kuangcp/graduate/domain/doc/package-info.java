/**
 * Created by https://github.com/kuangcp
 * 文档操作的数据类型
 * @author kuangcp
 * @date 18-5-2  上午9:46
 */
package top.kuangcp.graduate.domain.doc;
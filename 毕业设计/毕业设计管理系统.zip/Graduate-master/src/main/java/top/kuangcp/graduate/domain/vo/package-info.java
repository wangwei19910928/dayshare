/**
 * Created by https://github.com/kuangcp
 * 视图层对象
 * @author kuangcp
 * @date 18-5-2  上午10:03
 */
package top.kuangcp.graduate.domain.vo;
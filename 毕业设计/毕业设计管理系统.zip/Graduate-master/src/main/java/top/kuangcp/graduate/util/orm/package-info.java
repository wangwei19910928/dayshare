/**
 * Created by https://github.com/kuangcp
 * 个人开发 MythORM 框架， 移除掉， 因为这样的用法是浪费资源
 * @author kuangcp
 * @date 18-4-21  下午6:32
 */
package top.kuangcp.graduate.util.orm;
package top.kuangcp.graduate.domain.vo.result;

/**
 * Created by https://github.com/kuangcp
 *
 * @author kuangcp
 * @date 18-4-30  下午8:57
 */
public interface Result {
}

//package top.kuangcp.graduate.config;
//
//import org.springframework.boot.context.properties.EnableConfigurationProperties;
//import org.springframework.context.annotation.Configuration;
//import top.kuangcp.graduate.config.custom.MainConfig;
//
///**
// * Created by https://github.com/kuangcp
// *
// * @author kuangcp
// * @date 18-4-22  下午7:54
// */
//@Configuration
//@EnableConfigurationProperties(MainConfig.class)
//public class AutoCustomConfig {
//}

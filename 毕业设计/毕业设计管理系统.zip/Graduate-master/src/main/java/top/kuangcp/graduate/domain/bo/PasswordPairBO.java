package top.kuangcp.graduate.domain.bo;

import lombok.Data;

/**
 * Created by https://github.com/kuangcp
 *
 * @author kuangcp
 * @date 18-5-5  下午12:46
 */
@Data
public class PasswordPairBO {
    String oldPass;
    String newPass;
}

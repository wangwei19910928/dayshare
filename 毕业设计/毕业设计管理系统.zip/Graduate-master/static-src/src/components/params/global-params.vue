<<script>

const baseUri = 'http://192.168.43.40:8889/api';
const studentId = 'studentId';

export default {
  baseUri,
  studentId
}
</script>

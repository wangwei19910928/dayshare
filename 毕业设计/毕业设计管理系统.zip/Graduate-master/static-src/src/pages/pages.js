import Index from './index'
import Detail from './detail'

export default {
  Index,
  Detail
}

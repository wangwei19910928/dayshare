var host = '/api';
var mythos = 'randomValue';
var delimiter_num = 'N';

package com.zhang.ssmschoolshop.entity;

/**
 * Created by 文辉 on 2017/7/27.
 */
public class GoodsPrice {

}

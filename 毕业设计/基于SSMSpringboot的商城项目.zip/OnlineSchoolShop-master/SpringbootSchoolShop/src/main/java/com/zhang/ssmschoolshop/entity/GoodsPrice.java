package com.zhang.ssmschoolshop.entity;

public class GoodsPrice {

}

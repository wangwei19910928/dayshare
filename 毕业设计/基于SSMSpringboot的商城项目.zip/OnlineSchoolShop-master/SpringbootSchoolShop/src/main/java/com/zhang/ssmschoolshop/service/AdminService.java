package com.zhang.ssmschoolshop.service;


import com.zhang.ssmschoolshop.entity.Admin;

public interface AdminService {
    public Admin selectByName(Admin admin);
}

/**
 * Created by landyChris on 2017/10/29.
 */
public class Test {
    public Test() {
        System.out.println("A ClassLoader:" + this.getClass().getClassLoader() + " from classpath");
    }
}

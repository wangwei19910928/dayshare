#Flutter
##&emsp;一、你好，Flutter
###&emsp;&emsp; [原生开发与跨平台技术](https://www.jianshu.com/p/661cd7f22b70)
###&emsp;&emsp;  [初识Flutter]( https://flutter.cn/docs)
###&emsp;&emsp; [Flutter开发环境搭建](https://www.jianshu.com/p/11d5303fe9a8)
##&emsp;二、Flutter 编码语言Dart详解系列
###&emsp;&emsp;[Dart语法篇之基础语法(一)]( https://www.jianshu.com/p/6a25aa77846a)
###&emsp;&emsp;[Dart语法篇之集合的使用与源码解析(二)](https://www.jianshu.com/p/52be8389e368)
###&emsp;&emsp;[Dart语法篇之集合操作符函数与源码分析(三)](https://www.jianshu.com/p/3d320e232924)
###&emsp;&emsp;[Dart语法篇之函数的使用(四)](https://www.jianshu.com/p/059a68bc3eb6)
###&emsp;&emsp;[Dart语法篇之面向对象基础(五)](https://www.jianshu.com/p/c1b062889e03)
###&emsp;&emsp;[Dart语法篇之面向对象继承和Mixins(六)](https://www.jianshu.com/p/447f38f10eb9)
###&emsp;&emsp;[Dart语法篇之类型系统与泛型(七)](https://www.jianshu.com/p/8199e6588549)·
##&emsp;三、Flutter框架原理与使用技巧
###&emsp;&emsp;[widget控件详解：text,image,button](https://www.jianshu.com/p/e547e0fd45b5)
###&emsp;&emsp;[布局分析：Linear布局，弹性布局，流水布局](https://www.jianshu.com/p/5b0d4e2a8159)
###&emsp;&emsp;[如何自定义View](https://www.jianshu.com/p/b437adedbcff)
###&emsp;&emsp;[动画/手势交互](https://www.jianshu.com/p/74e7b3b771e6)
###&emsp;&emsp;[多线程开发原理](https://www.jianshu.com/p/12e06ba927f0)
###&emsp;&emsp;[网络请求原理](https://www.jianshu.com/p/51f6aeff5450)
###&emsp;&emsp;[Flutter架构与原生代码的交互](https://www.jianshu.com/p/74e7b3b771e6)
###&emsp;&emsp;实战发布自己的Flutter库
##&emsp;四、Flutter架构知识落地实现
###&emsp;&emsp;[干货集中营 gank app项目实战](https://www.jianshu.com/p/a1d069dcc0bd)
###&emsp;&emsp;[WanAndroid API构建客户端项目实战](https://www.jianshu.com/p/9e8cce5c567a)

## 最后

Alvin老师已经将精品网课、书籍、BAT面试文档、项目专题源码等资料已分享在网盘中，并在持续更新中。欢迎关注Alvin老师微信号VX：wxid_mgooud8xhvag12 前往领取！

![](https://upload-images.jianshu.io/upload_images/19956127-031f5138826d348a.jpeg?imageMogr2/auto-orient/strip|imageView2/2/w/564/format/webp)

**Android架构师之路很漫长，一起共勉吧！喜欢的话别忘记点击关注和赞哦**
